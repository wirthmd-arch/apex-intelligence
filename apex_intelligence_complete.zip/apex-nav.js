/* ============================================================
   APEX INTELLIGENCE — Shared Navigation Component (apex-nav.js)
   Renders the top header bar + group/tab nav bar on every page.
   Import after React and apex-store.js.
   Usage: h(ApexNav, { activeTab: 'tradeprompt' })
   ============================================================ */

var APEX_NAV_GROUPS = [
  {id:'portfolio', label:'Portfolio', icon:'ti-briefcase',
   tabs:['summary','dashboard','positions','watchlist','alerts','topgrades','dividends','analytics','taxlots','paper','networth','stress','benchmark','rebalance','cryptoport']},
  {id:'markets',   label:'Markets',   icon:'ti-chart-area',
   tabs:['macro','calendar','earnings','rates','crypto','funds','bonds','sentiment','econinds','heatmap','rotation','breadth','ipo','splits']},
  {id:'research',  label:'Research',  icon:'ti-search',
   tabs:['screener','compare','fundamentals','etfxray','cttracker','congress','wallfirms','analystratings','morningstar','dcf','shortflow']},
  {id:'trading',   label:'Trading',   icon:'ti-trending-up',
   tabs:['fastmoney','options','analysis','advisor','triggers','sizing','dca','journal','rrisk','greeks']},
  {id:'planning',  label:'Planning',  icon:'ti-umbrella',
   tabs:['insurance','retirement','credit','socsec','broker','inflation']},
  {id:'more',      label:'More',      icon:'ti-dots',
   tabs:['events','stockpicks','tradeprompt','settings']},
];

var APEX_MORE_TABS = [
  {id:'events',      icon:'ti-news',        label:'Event Plays',          href:'more-events.html'},
  {id:'stockpicks',  icon:'ti-rocket',      label:'Stock Picks',          href:'more-stockpicks.html'},
  {id:'tradeprompt', icon:'ti-prompt',      label:'Trade Advisor',        href:'more-tradeprompt.html'},
  {id:'settings',    icon:'ti-settings',    label:'Settings',             href:'more-settings.html'},
];

var APEX_PLANNING_TABS = [
  {id:'insurance',   icon:'ti-shield-check',     label:'Life Insurance',       href:'planning-insurance.html'},
  {id:'retirement',  icon:'ti-umbrella',          label:'Retirement Planner',   href:'planning-retirement.html'},
  {id:'credit',      icon:'ti-credit-card',       label:'Credit & Debt',        href:'planning-credit.html'},
  {id:'socsec',      icon:'ti-coin',              label:'Social Security',      href:'planning-socsec.html'},
  {id:'broker',      icon:'ti-building-store',    label:'Broker Guide',         href:'planning-broker.html'},
  {id:'inflation',   icon:'ti-receipt-tax',       label:'Inflation Calc',       href:'planning-inflation.html'},
];

var APEX_TRADING_TABS = [
  {id:'fastmoney', icon:'ti-bolt',               label:'Fast Money',          href:'trading-fastmoney.html'},
  {id:'options',   icon:'ti-replace',             label:'Options',             href:'trading-options.html'},
  {id:'analysis',  icon:'ti-chart-line',          label:'Analysis & Backtest', href:'trading-analysis.html'},
  {id:'advisor',   icon:'ti-message-chatbot',     label:'Stock Advisor',       href:'trading-advisor.html'},
  {id:'triggers',  icon:'ti-bell-ringing',        label:'Alert Triggers',      href:'trading-triggers.html'},
  {id:'sizing',    icon:'ti-calculator',          label:'Position Sizing',     href:'trading-sizing.html'},
  {id:'dca',       icon:'ti-repeat',              label:'DCA Simulator',       href:'trading-dca.html'},
  {id:'journal',   icon:'ti-notebook',            label:'Trade Journal',       href:'trading-journal.html'},
  {id:'rrisk',     icon:'ti-chart-area-filled',   label:'Options Risk Graph',  href:'trading-rrisk.html'},
  {id:'greeks',    icon:'ti-math-symbols',        label:'Options Greeks',      href:'trading-greeks.html'},
];

var APEX_RESEARCH_TABS = [
  {id:'screener',       icon:'ti-filter',                label:'Stock Screener',       href:'research-screener.html'},
  {id:'compare',        icon:'ti-arrows-diff',           label:'Stock Comparison',     href:'research-compare.html'},
  {id:'fundamentals',   icon:'ti-chart-bar',             label:'Fundamentals',         href:'research-fundamentals.html'},
  {id:'etfxray',        icon:'ti-zoom-in',               label:'ETF X-Ray',            href:'research-etfxray.html'},
  {id:'cttracker',      icon:'ti-user-search',           label:'Congress Tracker',     href:'research-cttracker.html'},
  {id:'congress',       icon:'ti-building-bank',         label:'Congress & World',     href:'research-congress.html'},
  {id:'wallfirms',      icon:'ti-building-skyscraper',   label:'Wall St Firms',        href:'research-wallfirms.html'},
  {id:'analystratings', icon:'ti-star',                  label:'Analyst Ratings',      href:'research-analystratings.html'},
  {id:'morningstar',    icon:'ti-star-half',             label:'Morningstar',          href:'research-morningstar.html'},
  {id:'dcf',            icon:'ti-binary-tree',           label:'Valuation & Targets',  href:'research-dcf.html'},
  {id:'shortflow',      icon:'ti-activity',              label:'Short & Options Flow', href:'research-shortflow.html'},
];

var APEX_MARKETS_TABS = [
  {id:'macro',     icon:'ti-world-cog',        label:'Macro Dashboard',      href:'markets-macro.html'},
  {id:'calendar',  icon:'ti-calendar-event',   label:'Economic Calendar',    href:'markets-calendar.html'},
  {id:'earnings',  icon:'ti-report-money',     label:'Earnings Calendar',    href:'markets-earnings.html'},
  {id:'rates',     icon:'ti-home',             label:'Rates',                href:'markets-rates.html'},
  {id:'crypto',    icon:'ti-currency-bitcoin', label:'Crypto & Rates',       href:'markets-crypto.html'},
  {id:'funds',     icon:'ti-chart-pie',        label:'Funds & ETFs',         href:'markets-funds.html'},
  {id:'bonds',     icon:'ti-building-bank-2',  label:'Bonds & Fixed Income', href:'markets-bonds.html'},
  {id:'sentiment', icon:'ti-mood-happy',       label:'News Sentiment',       href:'markets-sentiment.html'},
  {id:'econinds',  icon:'ti-chart-dots-3',     label:'Economic Indicators',  href:'markets-econinds.html'},
  {id:'heatmap',   icon:'ti-layout-grid',      label:'Market Heatmap',       href:'markets-heatmap.html'},
  {id:'rotation',  icon:'ti-refresh',          label:'Sector Rotation',      href:'markets-rotation.html'},
  {id:'breadth',   icon:'ti-wave-sine',        label:'Market Breadth',       href:'markets-breadth.html'},
  {id:'ipo',       icon:'ti-trending-up',      label:'IPO Calendar',         href:'markets-ipo.html'},
  {id:'splits',    icon:'ti-scissors',         label:'Stock Splits',         href:'markets-splits.html'},
];

var APEX_PORTFOLIO_TABS = [
  {id:'summary',    icon:'ti-news',                       label:'Market Summary',      href:'portfolio-summary.html'},
  {id:'dashboard',  icon:'ti-layout-dashboard',           label:'Dashboard',           href:'portfolio-dashboard.html'},
  {id:'positions',  icon:'ti-briefcase',                  label:'My Positions',        href:'portfolio-positions.html'},
  {id:'watchlist',  icon:'ti-eye',                        label:'Watchlist',           href:'portfolio-watchlist.html'},
  {id:'alerts',     icon:'ti-bell',                       label:'Alerts',              href:'portfolio-alerts.html'},
  {id:'topgrades',  icon:'ti-star',                       label:'Top Grades',          href:'portfolio-topgrades.html'},
  {id:'dividends',  icon:'ti-coin',                       label:'Dividend Tracker',    href:'portfolio-dividends.html'},
  {id:'analytics',  icon:'ti-chart-dots-3',               label:'Portfolio Analytics', href:'portfolio-analytics.html'},
  {id:'taxlots',    icon:'ti-receipt-tax',                label:'Tax Lots',            href:'portfolio-taxlots.html'},
  {id:'paper',      icon:'ti-flask',                      label:'Paper Trading',       href:'portfolio-paper.html'},
  {id:'networth',   icon:'ti-scale',                      label:'Net Worth',           href:'portfolio-networth.html'},
  {id:'stress',     icon:'ti-storm',                      label:'Stress Test',         href:'portfolio-stress.html'},
  {id:'benchmark',  icon:'ti-chart-arrows-vertical',      label:'vs Benchmark',        href:'portfolio-benchmark.html'},
  {id:'rebalance',  icon:'ti-adjustments-horizontal',     label:'Rebalancing',         href:'portfolio-rebalance.html'},
  {id:'cryptoport', icon:'ti-currency-bitcoin',           label:'Crypto Portfolio',    href:'portfolio-cryptoport.html'},
];

var APEX_ALL_EXTERNAL = APEX_MORE_TABS.concat(APEX_PLANNING_TABS).concat(APEX_TRADING_TABS).concat(APEX_RESEARCH_TABS).concat(APEX_MARKETS_TABS).concat(APEX_PORTFOLIO_TABS);

function ApexNav(props) {
  var activeTab = props.activeTab || '';

  /* Which group is active -- always 'more' for standalone pages */
  var activeGroup = APEX_NAV_GROUPS.find(function(g) {
    return g.tabs.indexOf(activeTab) >= 0 || g.id === activeTab;
  }) || APEX_NAV_GROUPS[5]; /* default to More */

  /* Theme toggle -- reads/writes same key as main app */
  var ts = React.useState(function(){ return lsGet('apex_theme','dark'); });
  var theme = ts[0], setThemeState = ts[1];

  function changeTheme(t) {
    setThemeState(t);
    lsSet('apex_theme', t);
    var root = document.documentElement;
    root.className = t === 'light' ? 'light' : t === 'system' ?
      (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : '') : '';
    applyTheme(t);
  }

  /* Keys/AI badge */
  var keys = lsGet('apex_pkeys', {});
  var activeAI = lsGet('apex_ai', 'gemini');
  var hasAK = !!(keys['openai'] || keys['gemini'] || keys['grok']);
  var aiProv = AI_PROVS.find(function(x){ return x.id === activeAI; }) ||
               {label: activeAI, color: C.muted, icon: 'ti-brain'};

  /* Which sub-tab list to show */
  var subTabs = activeGroup.id === 'more'       ? APEX_MORE_TABS :
                activeGroup.id === 'planning'   ? APEX_PLANNING_TABS :
                activeGroup.id === 'trading'    ? APEX_TRADING_TABS :
                activeGroup.id === 'research'   ? APEX_RESEARCH_TABS :
                activeGroup.id === 'markets'    ? APEX_MARKETS_TABS :
                activeGroup.id === 'portfolio'  ? APEX_PORTFOLIO_TABS : null;

  function navTo(tabId) {
    window.location.href = 'apex_intelligence.html#tab=' + tabId;
  }

  return h(React.Fragment, null,
    /* ── Top header bar ── */
    h('div', {className: 'hdr'},
      h('div', {style: {display:'flex', alignItems:'center', gap:10}},
        h('div', {style: {width:30, height:30, background:'rgba(245,200,66,.15)',
          border:'1px solid rgba(245,200,66,.4)', borderRadius:6,
          display:'flex', alignItems:'center', justifyContent:'center'}},
          h('i', {className:'ti ti-chart-candle', style:{fontSize:16, color:C.gold}})
        ),
        h('div', null,
          h('div', {style:{fontSize:14, fontWeight:700, color:C.gold, letterSpacing:'0.05em'}},
            'Apex Intelligence'),
          h('div', {style:{fontSize:10, color:C.muted, letterSpacing:'0.1em', textTransform:'uppercase'}},
            'Congressional & Executive Monitor')
        ),
        hasAK
          ? h('span', {style:{display:'inline-flex', alignItems:'center', gap:4, fontSize:10,
              background: aiProv.color+'20', color: aiProv.color,
              border:'1px solid '+aiProv.color+'40', padding:'2px 7px', borderRadius:3, fontWeight:700}},
              h('i', {className:'ti '+aiProv.icon}), aiProv.label)
          : h('button', {className:'btn btn-gold',
              style:{fontSize:10, padding:'3px 10px'},
              onClick:function(){ window.location.href='more-settings.html'; }},
              h('i', {className:'ti ti-key'}), ' Add API keys ->')
      ),
      h('div', {style:{display:'flex', alignItems:'center', gap:12}},
        h('span', {style:{fontSize:11, fontFamily:C.mono, color:C.muted}},
          new Date().toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'})
        ),
        /* Theme toggle */
        h('div', {style:{display:'flex', gap:2, background:'rgba(0,0,0,.2)', borderRadius:5, padding:2}},
          [['dark','ti-moon','Dark'],['light','ti-sun','Light'],['system','ti-device-laptop','Auto']].map(function(tm){
            var isActive = theme === tm[0];
            return h('button', {key:tm[0],
              style:{background: isActive?'rgba(77,158,255,.2)':'transparent',
                border: isActive?'1px solid rgba(77,158,255,.4)':'1px solid transparent',
                borderRadius:4, padding:'3px 7px', cursor:'pointer',
                display:'flex', alignItems:'center', gap:3,
                color: isActive?C.blue:C.muted, fontSize:10, fontFamily:'inherit', transition:'all .15s'},
              onClick:function(){ changeTheme(tm[0]); }},
              h('i', {className:'ti '+tm[1], style:{fontSize:11}}), tm[2]
            );
          })
        ),
        /* Back to app */
        h('a', {href:'apex_intelligence.html',
          style:{display:'inline-flex', alignItems:'center', gap:4, fontSize:10, fontWeight:600,
            color:C.muted, background:'rgba(0,0,0,.2)', border:'1px solid transparent',
            borderRadius:5, padding:'3px 8px', textDecoration:'none', cursor:'pointer'},
          title:'Back to main app'},
          h('i', {className:'ti ti-layout-grid', style:{fontSize:11}}), ' All Sections'
        )
      )
    ),
    /* ── Group nav row ── */
    h('div', {className:'nav2'},
      h('div', {className:'nav2-groups'},
        APEX_NAV_GROUPS.map(function(g) {
          var isActive = g.id === activeGroup.id;
          return h('button', {key:g.id,
            className:'nav2-grp' + (isActive?' active':''),
            onClick:function(){
              if(g.id === 'more') {
                window.location.href = APEX_MORE_TABS[0].href;
              } else if(g.id === 'planning') {
                window.location.href = APEX_PLANNING_TABS[0].href;
              } else if(g.id === 'trading') {
                window.location.href = APEX_TRADING_TABS[0].href;
              } else if(g.id === 'research') {
                window.location.href = APEX_RESEARCH_TABS[0].href;
              } else if(g.id === 'markets') {
                window.location.href = APEX_MARKETS_TABS[0].href;
              } else if(g.id === 'portfolio') {
                window.location.href = APEX_PORTFOLIO_TABS[0].href;
              } else {
                window.location.href = 'apex_intelligence.html#tab=' + g.tabs[0];
              }
            }
          }, h('i', {className:'ti '+g.icon}), h('span', null, g.label));
        })
      ),
      /* ── Sub-tab row ── */
      subTabs ? h('div', {className:'nav2-tabs'},
        subTabs.map(function(t) {
          var isActive = t.id === activeTab;
          return h('button', {key:t.id,
            className:'nav2-tab' + (isActive?' active':''),
            onClick:(function(href){ return function(){ window.location.href = href; }; })(t.href)
          },
          h('i', {className:'ti '+t.icon}),
          h('span', null, t.label)
          );
        })
      ) : null
    )
  );
}
