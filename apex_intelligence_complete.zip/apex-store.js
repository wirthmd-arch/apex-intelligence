/* ============================================================
   APEX INTELLIGENCE — Shared Store (apex-store.js)
   Cross-tab sync, localStorage key reference, and safeLP.
   NOTE: lsGet, lsSet, C, scColor, recLabel, recColor, dollar,
   fmtMoney, fmtRate, fmtTS, applyTheme, openY, openG, PCKEY,
   qhKey, loadPC, savePC are all defined in the page's own
   inline script (extracted from apex_intelligence.html) to
   avoid duplicate-declaration errors. This file only provides
   what is NOT already in that preamble.
   Import in every page BEFORE apex-nav.js and the page script.
   ============================================================ */

/* ----- Theme bootstrap (runs immediately, before paint) ----- */
(function(){
  try{
    var t=JSON.parse(localStorage.getItem('apex_theme')||'null')||localStorage.getItem('apex_theme');
    if(t==='light'){document.documentElement.classList.add('light');}
    else if(t==='system'||!t){
      if(window.matchMedia&&window.matchMedia('(prefers-color-scheme: light)').matches){
        document.documentElement.classList.add('light');
      }
    }
  }catch(e){}
})();

/* ----- localStorage keys reference ----- */
const LS_KEYS = {
  positions:    'apex_pos',
  watchlist:    'apex_watch',
  priceKeys:    'apex_pkeys',
  activeAI:     'apex_ai',
  aiGoals:      'apex_ai_goals',
  activePP:     'apex_pp',
  theme:        'apex_theme',
  triggers:     'apex_triggers',
  freeCash:     'apex_free_cash',
  snapshots:    'apex_perf_v1',
  priceCache:   'apex_price_v3',
  phaseCache:   'apex_phase_cache',
  journalTrades:'apex_journal',
};

/* ----- Cross-tab sync (BroadcastChannel) ----- */
const apexChannel = (typeof BroadcastChannel !== 'undefined') ? new BroadcastChannel('apex_sync') : null;
function apexBroadcast(type, payload){
  if(apexChannel) apexChannel.postMessage({type, payload, ts: Date.now()});
}
/* Pages listen via: apexChannel.onmessage = e => { ... } */

/* ----- Navigation helper: go to a tab in the main app ----- */
function apexNavigate(tabId){
  window.location.href = 'apex_intelligence.html#tab=' + tabId;
}
